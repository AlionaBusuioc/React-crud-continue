import React, {Component} from 'react';
import {Table} from 'react-bootstrap';
import Product from './Product';
import faker from 'faker';

class ProductList extends Component {
  getProducts(){
let products =[];
while(products.length<10){
  products.push({
photo: faker.image.technics(100,100),
name: faker.commerce.productName(),
price: {
  amount: faker.commerce.price(500,5000),
  currency: "USD"
},
rating: faker.random.rating,
promo: true
  });
}
    return [{
      //+Bonus class Product() -->newProduct(....)
      //+Bonus npm -> faker ->generate products()
      photo: "./images/pl.jpg",
      name: "aiFoon xxl",
      price:{
        amount:100,
        currency: "USD"
      },
      rating: 4.5,
      promo: true
      },
    ]
  }

render(){
  let data = this.getProducts();
  return(
    <div className="container">
      <Product data={data[0]} mode="admin"/>
    </div>
  )}
//     return(
//       <div class="container mt-3" >
//         <Table striped bordered hover>
//   <thead>
//     <tr>
//       <th>Photo</th>
//       <th>Name</th>
//       <th>Price</th>
//       <th>Rating</th>
//     </tr>
//   </thead>
//   <tbody>
//     {/* ciclu /for - cu froduse*/}
//     <tr>
//       <td>1</td>
//       <td>Mark</td>
//       <td>Otto</td>
//       <td>@mdo</td>
//     </tr>
//     <tr>
//       <td>2</td>
//       <td>Jacob</td>
//       <td>Thornton</td>
//       <td>@fat</td>
//     </tr>
//     <tr>
//       <td>3</td>
//       <td colSpan="2">Larry the Bird</td>
//       <td>@twitter</td>
//     </tr>
//   </tbody>
// </Table>
// </div>
//     )
// }
}
export default ProductList;