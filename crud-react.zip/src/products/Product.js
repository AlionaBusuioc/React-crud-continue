import React, {Component} from 'react';
import {Dropdown, Image} from 'react-bootstrap';

class Product extends Component {
    constructor(props){
        super(props);
        this.state = {
            data: this.props.data, //data produsului
            mode: this.props.mode, //regimul de afisare
            //vor exista moduri: compact, preview, full
            // data: {
            //     photo: "./images/p1.jpg",
            //     name: "aiFoone xxl",
            //     price: {
            //         amount:100,
            //         currency: "USD"
            //     },
            //     raiting: 4.5,
            //     promo: true
            // }
        }
    }
    render(){
        let data = this.state.data;
        let mode = this.state.mode;
        let dom = <div className="product">
        <img src ={data.photo}/>
        <h2>{data.name}</h2>
        <p>{data.price.amount}</p>
        </div>;

        switch (mode) {
            case "compact":
                dom = <div className="product">
                <img src ={data.photo} width="100"/>
                <h2>{data.name}</h2>
                <p>{data.price.amount}</p>
                </div>;
            break;
            case"preview":break;
            case "full":break;
            case "admin":
            dom = <div className="product">
                <div className="col-1">
                <Image src={data.photo} fluid/>
                </div>
                <img src={data.photo} width="100" alt="/"/>
                <h2 class="col-2">{data.name}</h2>
                <p class="col-2">{data.price.amount}</p>
                <Dropdown class="col-2">
                    <Dropdown.Toggle variant="primary" id="dropdown-basic">
                        Actions
                    </Dropdown.Toggle>
                    <Dropdown.Menu>
                        <Dropdown.Item href="#/action">View</Dropdown.Item> 
                        <Dropdown.Item href="">Edit</Dropdown.Item> 
                        <Dropdown.Item href="">Remove</Dropdown.Item> 
                        <Dropdown.Item href="">Publish</Dropdown.Item> 
                    </Dropdown.Menu>
                </Dropdown>
            </div>
            break;
        }
        return(
        dom
        );
    }
}
export default Product;