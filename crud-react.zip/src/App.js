import React from 'react';
import {BrowserRouter as Router,Link, Route} from 'react-router-dom'
import {Navbar,Button} from 'react-bootstrap'
// import logo from './logo.svg';
import './App.css';
import ProductForm from './products/ProductForm';
import ProductList from './products/ProductList';
import Product from './products/Product';

function App() {
  return (
    <div className="App">
      <Product data ={
        {
          photo: "./images/p1.jpg",
          name: "aiFoone xxl",
          price: {
              amount:100,
              currency: "USD"
          },
          raiting: 4.5,
          promo: true
      }
      }
      mode="compact"
      />
      <Router>
      <Route path="/product/add" component={ProductForm}/>
      <Route path="/products" component={ProductList}/>
      <Route path="/product/detail" component={Product}/>

        <Navbar className="container" fixed="bottom">
        <Link to="/products" className="mr-auto">
          <Button variant="secondary" size="lg" className="shadow">Products
          </Button>
        </Link>
        <Link to="/product/detail" className="mr-auto">
          <Button variant="secondary" size="lg" className="shadow">Products
          </Button>
        </Link>
        <Link to="/product/add" className="ml-auto">
          <Button variant="primary" size="lg" className="rounded-pill shadow">+
          </Button>
        </Link>
        </Navbar>
        {/* <Route path="/product/add" component={ProductForm}/> */}
      </Router>
    </div>
  );
}

export default App;
